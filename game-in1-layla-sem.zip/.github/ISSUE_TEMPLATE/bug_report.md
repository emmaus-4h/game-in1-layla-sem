---
name: Bug report
about: Beschrijf hier een grote of kleine fout in je game
title: 'BUG: [korte beschrijving]'
labels: bug
assignees: ''

---

**Beschrijf de bug**
Kort maar krachtig.

**Hoe reproduceer je de bug**
Beschrijf de stappen:
1. Ga naar scherm / level '...'
2. Doe '....'
3. Daarna '....'
4. De fout is: 

**Wat moet er wèl gebeuren**
A clear and concise description of what you expected to happen.

**Screenshots**
Indien nodig, voeg een screenshot toe
