Deze game is gebaseerd op het template voor 4HV van het Emmauscollege Rotterdam

## Mijn spel: *naam van het spel*
Gemaakt door:
- * Layla Lemhaouli*
- * Sem Lindeboom *

## Mijn planning

Basis: uitleg, spelen, afgaan en punten
- [x] maak index.html, style.css en script.js met canvas
- [ ] teken speler
- [ ] beweeg speler
- [ ] ... *(vul zelf aan)*
- [ ] punten op scherm zetten
- [ ] punten kunnen scoren
- [ ] uitlegscherm

Uitbreiding: *bedenk iets, bijvoorbeeld meer tegenstanders*
- [ ] *later uitwerken*
- [ ] *later uitwerken*
- [ ] *later uitwerken*

Uitbreiding: *bedenk iets, bijvoorbeeld bewegende achtergrond*
- [ ] *later uitwerken*
- [ ] *later uitwerken*
- [ ] *later uitwerken*

## Credits
- Game template van het Emmauscollege Rotterdam https://github.com/emmauscollege/4HV-game-template
- manifest.json https://codelabs.developers.google.com/codelabs/your-first-pwapp/#3
- icon http://www.iconarchive.com/show/android-lollipop-icons-by-dtafalonso/Play-Games-icon.html
- ...
